package com.portfolio.bit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BitApplicationTests {

	@Test
	void contextLoads() {
	}

}
